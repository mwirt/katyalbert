<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
<script>
  WebFont.load({
    google: {
      families: ['Source Sans Pro: 400, 400i, 700']
    }
  });
</script>
;
